try:
    from PIL import Image
except ImportError:
    import Image
import pytesseract


def ocr_main(filename):
    """
    handle processsing of image
    """
    text = pytesseract.image_to_string(Image.open(filename))
    return text


print(ocr_main('images/image_6.png'))
